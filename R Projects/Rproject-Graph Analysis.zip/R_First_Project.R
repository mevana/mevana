install.packages("igraph")



library(igraph)



#prepare data
Contacts <- read.csv("C:\\Users\\madha\\Desktop\\nodes.csv", header=T, as.is=T)
Emails <- read.csv("C:\\Users\\madha\\Desktop\\edges.csv", header=T, as.is=T)
net <- graph_from_data_frame(d=Emails, vertices=Contacts, directed=F) 
gorder(net)
gsize(net)
plot(net)


#--------------------do simplification--------------------
net <- simplify(net)
gsize(net)

#define a function that cuts all nodes which have <= nEdge

#cut all nodes with less than 4 edges
#net <- CutNodes(net, 5)
net <- delete_vertices(net, which(degree(net) < 55))
gorder(net)
gsize(net)
plot.igraph(net)
as_data_frame(net, what = "Vertices")
#net <- delete.edges(net, which(degree(net) < 4))
#gorder(net)
#gsize(net)
#as_data_frame(net, what = "Edges")



#another way to model the graph is to calculate how strong a link is
#E(graph)$weight <- 1
#simplify(graph, edge.attr.comb=list(weight="sum"))
#assign a weight of 1 to each edge and then collapsing multiple edges into single ones while summing the weights

#Task-4 Use 10 functions
#1 #The diameter of a graph is the length of the longest geodesic
diameter(net, directed = TRUE, unconnected = TRUE, weights = NULL)


#2  ADhesion
adhesion(net)
edge_connectivity(net, source = NULL, target = NULL, checks = TRUE)
plot.igraph(net)

#3 Convert a graph to an adjacency matrix

as_adj(net, type = c("both", "upper", "lower"), attr = NULL,
       edges = TRUE, names = TRUE, sparse = igraph_opt("sparsematrices"))

#4 DataFrame-edges and vertices

as_data_frame(net, what="vertices")
as_data_frame(net, what="edges")

#5biconnected_components
biconnected_components(net)
plot.igraph(net)
#g <- disjoint_union( make_full_graph(5), make_full_graph(5) )
#clu <- components(g)$membership
#g <- add_edges(g, c(which(clu==1), which(clu==2)))
#bc <- biconnected_components(g)
#bc
#6 Power Centerality:
power_centrality(net, nodes = V(net), loops = FALSE,
                 exponent = 1, rescale = FALSE, tol = 1e-07, sparse = TRUE)


#7 Clusters
components(net)
x = component_distribution(net,cumulative = TRUE)
length(x)


#8 Decompose a graph
decompose(net, mode = c("weak", "strong"), max.comps = NA,
          min.vertices = 10)
decompose.graph(net, mode = c("weak", "strong"), max.comps = NA,
          min.vertices =1)
plot.igraph(net)

#9Count no of triangles 
count_triangles(net, vids = V(net))

#10IVS:
# A quite dense graph
set.seed(42)

ivs_size(net)
ivs(net, min=ivs_size(net))
largest_ivs(net)
# Empty graph
induced_subgraph(net, largest_ivs(net)[[1]])

length(maximal_ivs(net))



## End(Not run)

ivs(net, min = NULL, max = NULL)



#11
edges<-get.edgelist(net)
v1<-edges[1,10]
v1




ends(net, E(net))

#12
radius(net, mode = c("all", "out", "in", "total"))



#--------------------analyze graph--------------------
#1.central nodes
#V(net)$name[degree(net)==max(degree(net))]
centDegree <- centr_degree(net)
#$res is a list of center scores for each node. We are interested in what the node is so we need to turn it into node id
lsCenterResult <- setNames(centDegree$res, V(net)$name)
head(sort(lsCenterResult, decreasing = T), 20)

#2.longest path
diameter(net)
get_diameter(net)

#3.largest cliques
largest_cliques(net)


#4.ego
ego(net, order = 1, nodes = c("david.forster@enron.com"))
#lsEgoGraph = make_ego_graph(net, order = 1, nodes = c("david.forster@enron.com", "elizabeth.sager@enron.com", "technology.enron@enron.com", "david.oxley@enron.com"))
#for (iter in lsEgoGraph) {
#    plot(iter)
#}

#5.power centrality
#need to try different values for exponent. Under some cases you get error: cs_lu(A) failed: near-singular A (or out of memory)
lsPowerResult <- power_centrality(net, exponent = 0.9)
PowerCentrality= head(sort(lsPowerResult, decreasing = T), 20)
plot(x)









library("readxl")
table= read_excel("C:\\Users\\madha\\Downloads\\Concrete_Data.xls")
length(table)
names(table)
table[1:10,]
#New table
new_table.df = table[,1:8]
names(new_table)
new_table.df[1:10,]
str(new_table.df)
#rete table converting it to numeric
New_auto = new_table.df
summary(New_auto)
auto.na= na.omit(New_auto)
str(auto.na)

#Psych function installation

install.packages("psych")
library(psych)
describe(auto.na)

plot(auto.na)
auto.na2 = auto.na[,1:6]
colheader <- c("cement", "blast", "ash", "water", "plastic", "coarse", "fine", "age", "compress")
names(auto.na2) <- colheader

plot(auto.na2)

#Scaling: we normalize so that larger values for certain variables 
#ontrwhelm the smaller values of other variables.
#Scaling
normalize = function(x) {(( x-min(x))/max(x)-min(x))}
normalize
auto_norm = as.data.frame(lapply(auto.na2[,1:6],normalize))
auto_norm[1:10,]  

auto.na2.cement = min(auto.na2$Cement)
auto.na2.cement
zscore = function(x){(x-mean(x))/sd(x)}
zscore(c(10,20,30,40,50))
auto_znorm = as.data.frame(lapply(auto.na2[,1:6],scale))
auto_znorm[1:10,]  
#K-means clustering
#k=2
auto_k2 = kmeans(auto_znorm, centers = 2, nstart=25)
auto_k2

#k=3
auto_k3= kmeans(auto_norm, centers = 3,nstart=25)
auto_k3
#k=4
auto_k4= kmeans(auto_norm, centers =4, nstart=25)
auto_k4
#K=5
auto_k5 = kmeans(auto_norm, centers = 5,nstart=25)
auto_k5
#k=6
auto_k6= kmeans(auto_norm, centers = 6, nstart=25)
auto_k6



install.packages("factoextra")
library(factoextra) 
fviz_cluster(auto_k6,auto.na2)
fviz_nbclust(auto.na2, FUNcluster=kmeans,print.summary=TRUE)

install.packages(c("cluster", "rattle","NbClust"))
library(cluster)
library(rattle)
library(NbClust)
wssplot = function(data, nc=15,seed=1234)
{
  wss = (nrow(data)-1)*sum(apply(data,2,var))
  for (i in 2:nc)
  {
    set.seed(seed)
    wss[i] = sum(kmeans(data,centers = i)$withinss)
  }
  plot(1:nc,wss,type='b',xlab= "Number of Clusters",ylab="No.of sqaures with groups")
}
wssplot(auto.na2,nc=6,seed=1234)  

fviz_nbclust(auto.na2, FUNcluster=kmeans,print.summary=TRUE)

#KNN clustering:
auto.norm.nrows = nrow(auto_norm)
auto.norm.sample = 0.7
auto.norm.train.index=sample(auto.norm.nrows,auto.norm.sample*auto.norm.nrows)
length(auto.norm.train.index)
auto.norm.train= auto_norm[auto.norm.train.index,]
auto.norm.train[1:20,]

auto.norm.test=auto_norm[-auto.norm.train.index,]  
auto.norm.test[1:20,]  

#Create training labels for kNN :

auto.norm.train.k4 = kmeans(auto.norm.train,centers = 4)
auto.norm.train.k4
install.packages('class')
library(class)
#k=2:
auto.norm.test.k2 = knn(auto.norm.train,auto.norm.test,auto.norm.train.k4$cluster,k=2)
auto.norm.test.k2
#k=3
auto.norm.test.k3 = knn(auto.norm.train,auto.norm.test,auto.norm.train.k4$cluster,k=3)
auto.norm.test.k3
#k=4
auto.norm.test.k4 = knn(auto.norm.train,auto.norm.test,auto.norm.train.k4$cluster,k=4)
auto.norm.test.k4
#k=5
auto.norm.test.k5 = knn(auto.norm.train,auto.norm.test,auto.norm.train.k4$cluster,k=5)
auto.norm.test.k5
#k=6
auto.norm.test.k6 = knn(auto.norm.train,auto.norm.test,auto.norm.train.k4$cluster,k=6)
auto.norm.test.k6

auto.norm.train.lables = auto.norm.train.k4$cluster
auto.norm.train.lables

#Create test labels via kmeans:


auto.norm.test.k4 = kmeans(auto.norm.test, centers = 4)
auto.norm.test.k4
#Evaluating kNN:Use CrossTable in gmodels package:
auto.norm.test.lables = auto.norm.test.k4$cluster
auto.norm.test.lables

auto.norm.test.pred= knn(auto.norm.train,auto.norm.test,auto.norm.train.k4$cluster,k=4)
str(auto.norm.test.pred)
install.packages("gmodels")
library(gmodels)
auto.norm.ct = CrossTable(auto.norm.test.lables,auto.norm.test.pred,prop.chisq = FALSE)  


#iclust
#iclust(auto_norm,nclusters = 2)
#iclust(mtcars,nclusters = 2)
iclust(auto.na2,nclusters = 2)
clusplot(pam(x=auto.na2,k=2,metric="euclidean", stand = FALSE))
clusplot(pam(x=auto.na2,k=2,metric="", stand = FALSE))
iclust(auto.na2,nclusters = 3)
